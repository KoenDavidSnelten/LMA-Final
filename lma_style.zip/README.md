# Course report template

Edit `lma_template.tex` and add references to `bib.bib`. The included PDF previews the writing instructions. Upload the files in this folder to Overleaf and select `lma_template.tex` as the main document, or compile locally:

```sh
pdflatex lma_template.tex
bibtex lma_template
pdflatex lma_template.tex
pdflatex lma_template.tex
```
